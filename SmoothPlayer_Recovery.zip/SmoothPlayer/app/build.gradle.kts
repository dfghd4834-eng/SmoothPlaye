plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.moulay.smoothplayer"
    compileSdk = 35
    defaultConfig { applicationId = "com.moulay.smoothplayer"; minSdk = 26; targetSdk = 35; versionCode = 1; versionName = "1.0" }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation("androidx.media3:media3-exoplayer:1.5.1")
    implementation("androidx.media3:media3-ui:1.5.1")
    implementation("androidx.media3:media3-exoplayer-hls:1.5.1")
    implementation("androidx.activity:activity-ktx:1.9.3")
}
