package com.moulay.smoothplayer

import android.app.Activity
import android.app.PictureInPictureParams
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.ComponentActivity
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

class MainActivity : ComponentActivity() {
    private lateinit var player: ExoPlayer
    private lateinit var view: PlayerView
    private lateinit var status: TextView
    private var video: Uri? = null
    private var subtitle: Uri? = null
    private var subtitleMime = MimeTypes.APPLICATION_SUBRIP
    private val skips = mutableListOf<Pair<Long, Long>>()
    private val blurs = mutableListOf<Pair<Long, Long>>()
    private lateinit var blurLayer: TextView
    private var blurEnabled = true
    private val handler = Handler(Looper.getMainLooper())
    private var speedIndex = 0
    private val speeds = floatArrayOf(1f, 1.1f, 1.25f, 1.5f, 2f)
    private val ticker = object : Runnable {
        override fun run() {
            if (::player.isInitialized && player.isPlaying) {
                val t = player.currentPosition
                skips.firstOrNull { t >= it.first && t < it.second }?.let { player.seekTo(it.second) }
                if (::blurLayer.isInitialized) {
                    blurLayer.visibility = if (blurEnabled && blurs.any { t >= it.first && t < it.second }) View.VISIBLE else View.GONE
                }
            }
            handler.postDelayed(this, 250)
        }
    }
    private val pickVideo = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) { video = uri; subtitle = null; loadSegments(); playMedia(0L) }
    }
    private val pickSubtitle = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null && video != null) {
            subtitle = uri
            val name = (android.provider.OpenableColumns.DISPLAY_NAME.let { column ->
                contentResolver.query(uri, arrayOf(column), null, null, null)?.use { cursor ->
                    if (cursor.moveToFirst()) cursor.getString(0) else null
                }
            } ?: uri.lastPathSegment.orEmpty()).lowercase()
            subtitleMime = if (name.endsWith(".vtt")) MimeTypes.TEXT_VTT else MimeTypes.APPLICATION_SUBRIP
            playMedia(player.currentPosition.coerceAtLeast(0L))
            status.text = "تمت إضافة الترجمة"
        }
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(12, 17, 30)
        window.navigationBarColor = Color.rgb(12, 17, 30)
        player = ExoPlayer.Builder(this).build()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(16), dp(14), dp(12))
            setBackgroundColor(Color.rgb(12, 17, 30))
        }
        val title = TextView(this).apply {
            text = "سلاسة  ✦"
            textSize = 27f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        root.addView(title, LinearLayout.LayoutParams(-1, dp(54)))
        status = TextView(this).apply {
            text = "مشغل فيديو خفيف • ترجمة • تخطي يدوي"
            setTextColor(Color.rgb(190, 205, 230))
            gravity = Gravity.CENTER
            textSize = 13f
        }
        root.addView(status)
        view = PlayerView(this).apply {
            player = this@MainActivity.player
            useController = true
            setBackgroundColor(Color.BLACK)
            keepScreenOn = true
        }
        val videoFrame = android.widget.FrameLayout(this)
        videoFrame.addView(view, android.widget.FrameLayout.LayoutParams(-1, -1))
        blurLayer = TextView(this).apply {
            text = "المشهد محجوب يدويًا"
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            textSize = 20f
            setBackgroundColor(Color.rgb(13, 17, 27))
            visibility = View.GONE
            setOnClickListener { visibility = View.GONE }
        }
        videoFrame.addView(blurLayer, android.widget.FrameLayout.LayoutParams(-1, -1))
        root.addView(videoFrame, LinearLayout.LayoutParams(-1, 0, 1f))
        val scroller = ScrollView(this)
        val controls = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroller.addView(controls)
        root.addView(scroller, LinearLayout.LayoutParams(-1, dp(295)))
        fun button(label: String, onClick: () -> Unit) {
            val b = TextView(this).apply {
                text = label
                gravity = Gravity.CENTER
                setTextColor(Color.WHITE)
                textSize = 15f
                setPadding(dp(12), dp(13), dp(12), dp(13))
                background = GradientDrawable().apply {
                    setColor(Color.argb(140, 56, 76, 108))
                    cornerRadius = dp(18).toFloat()
                    setStroke(dp(1), Color.argb(110, 225, 238, 255))
                }
                setOnClickListener { onClick() }
            }
            controls.addView(b, LinearLayout.LayoutParams(-1, dp(49)).apply { bottomMargin = dp(8) })
        }
        button("📁  فتح فيديو من الجهاز") { pickVideo.launch(arrayOf("video/*")) }
        button("📝  إضافة ترجمة SRT / VTT") { pickSubtitle.launch(arrayOf("*/*")) }
        button("🌐  تشغيل رابط HTTPS للفيديو أو M3U8") { inputDialog("رابط الفيديو", "https://", { input ->
            val u = Uri.parse(input)
            if (u.scheme == "https" && !u.host.isNullOrBlank()) { video = u; subtitle = null; loadSegments(); playMedia(0L) }
            else status.text = "استخدم رابط HTTPS صالح"
        }) }
        button("⏩  تغيير السرعة") {
            speedIndex = (speedIndex + 1) % speeds.size
            player.setPlaybackSpeed(speeds[speedIndex]); status.text = "السرعة ${speeds[speedIndex]}x (ليست توليد إطارات)"
        }
        button("🛡️  إضافة فترة تخطي للمشهد") { addSkipDialog() }
        button("🙈  حجب مشهد من اللحظة الحالية") { addBlurDialog() }
        button("👁️  تشغيل / إيقاف الحجب اليدوي") {
            blurEnabled = !blurEnabled
            status.text = if (blurEnabled) "الحجب اليدوي مفعل" else "الحجب اليدوي متوقف"
            if (!blurEnabled) blurLayer.visibility = View.GONE
        }
        button("🗑️  حذف فترات التخطي والحجب") {
            skips.clear(); blurs.clear(); saveSegments()
            blurLayer.visibility = View.GONE
            status.text = "تم مسح الفترات المحفوظة لهذا الفيديو"
        }
        button("▣  صورة داخل صورة") {
            if (Build.VERSION.SDK_INT >= 26) {
                try { enterPictureInPictureMode(PictureInPictureParams.Builder().build()) }
                catch (_: Exception) { status.text = "صورة داخل صورة غير متاحة" }
            }
        }
        button("⛶  ملء الشاشة") {
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        }
        setContentView(root)
        handler.post(ticker)
    }
    private fun playMedia(position: Long) {
        val uri = video ?: return
        val builder = MediaItem.Builder().setUri(uri)
        if (uri.toString().substringBefore('?').endsWith(".m3u8", true)) builder.setMimeType(MimeTypes.APPLICATION_M3U8)
        subtitle?.let {
            builder.setSubtitleConfigurations(listOf(MediaItem.SubtitleConfiguration.Builder(it)
                .setMimeType(subtitleMime).setLanguage("ar")
                .setSelectionFlags(C.SELECTION_FLAG_DEFAULT).build()))
        }
        player.setMediaItem(builder.build())
        player.prepare()
        player.seekTo(position)
        player.playWhenReady = true
        status.text = "جاهز للتشغيل"
    }
    private fun addSkipDialog() {
        if (video == null) { status.text = "افتح فيديو أولاً"; return }
        val start = player.currentPosition.coerceAtLeast(0L)
        inputDialog("مدة المشهد المراد تخطيه بالثواني (من اللحظة الحالية)", "30", { input ->
            val seconds = input.toLongOrNull()
            if (seconds != null && seconds in 1..3600) {
                skips.add(start to start + seconds * 1000)
                saveSegments()
                status.text = "تخطي من ${start / 1000} إلى ${(start / 1000) + seconds} ثانية"
            } else status.text = "أدخل عدد ثوانٍ من 1 إلى 3600"
        })
    }
    private fun addBlurDialog() {
        if (video == null) { status.text = "افتح فيديو أولاً"; return }
        val start = player.currentPosition.coerceAtLeast(0L)
        inputDialog("مدة الحجب بالثواني من اللحظة الحالية", "30") { input ->
            val seconds = input.toLongOrNull()
            if (seconds != null && seconds in 1..3600) {
                blurs.add(start to start + seconds * 1000)
                saveSegments()
                status.text = "تم حفظ فترة حجب يدوي لمدة $seconds ثانية"
            } else status.text = "المدة يجب أن تكون بين 1 و3600 ثانية"
        }
    }
    private fun segmentKey(): String? = video?.toString()?.let {
        "segments_" + java.security.MessageDigest.getInstance("SHA-256")
            .digest(it.toByteArray()).joinToString("") { b -> "%02x".format(b) }
    }
    private fun saveSegments() {
        val key = segmentKey() ?: return
        val payload = (skips.map { "S,${it.first},${it.second}" } +
            blurs.map { "B,${it.first},${it.second}" }).joinToString(";")
        getSharedPreferences("segments", MODE_PRIVATE).edit().putString(key, payload).apply()
    }
    private fun loadSegments() {
        skips.clear(); blurs.clear()
        val key = segmentKey() ?: return
        val saved = getSharedPreferences("segments", MODE_PRIVATE).getString(key, "").orEmpty()
        saved.split(';').forEach { entry ->
            val parts = entry.split(',')
            if (parts.size != 3) return@forEach
            val start = parts[1].toLongOrNull() ?: return@forEach
            val end = parts[2].toLongOrNull() ?: return@forEach
            if (start < 0 || end <= start) return@forEach
            when (parts[0]) {
                "S" -> skips.add(start to end)
                "B" -> blurs.add(start to end)
            }
        }
    }
    private fun inputDialog(title: String, initial: String, accept: (String) -> Unit) {
        val field = EditText(this).apply { setSingleLine(true); setText(initial); selectAll() }
        android.app.AlertDialog.Builder(this).setTitle(title).setView(field)
            .setPositiveButton("تأكيد") { _, _ -> accept(field.text.toString().trim()) }
            .setNegativeButton("إلغاء", null).show()
    }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    override fun onStop() {
        super.onStop()
        if (!isInPictureInPictureMode) player.pause()
    }
    override fun onDestroy() {
        handler.removeCallbacks(ticker)
        player.release()
        super.onDestroy()
    }
}
